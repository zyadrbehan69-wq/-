package com.ziyad.musnad

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

data class Theme(
    val name: String,
    val top: Int,
    val bottom: Int,
    val key: Int,
    val key2: Int,
    val text: Int,
    val accent: Int
)

object Themes {
    private fun c(s: String) = Color.parseColor(s)

    val list = listOf(
        Theme("كلاسيك", c("#E4E1D9"), c("#C9D6DC"), c("#EEEEE8"), c("#DDE3E3"), c("#111111"), c("#C95F2F")),
        Theme("ليلي", c("#2B2B2E"), c("#1B1B1D"), c("#3C3C40"), c("#2F2F33"), c("#F2F2F2"), c("#E0A35F")),
        Theme("أخضر", c("#DDEBDD"), c("#BFD8C4"), c("#F1F7F1"), c("#D3E4D6"), c("#10261A"), c("#2E7D4F")),
        Theme("أزرق", c("#DCE8F5"), c("#BBD0EA"), c("#F2F7FC"), c("#CFDDF0"), c("#0F1F33"), c("#2F6FD0")),
        Theme("بنفسجي", c("#E8E0F2"), c("#CFC2E4"), c("#F6F2FB"), c("#DDD2EE"), c("#21143A"), c("#7B4BC4")),
        Theme("وردي", c("#F6E1E6"), c("#EBC3CE"), c("#FCF1F4"), c("#F0D3DB"), c("#3A1420"), c("#D6477A"))
    )

    val accents = listOf("#C95F2F", "#2E7D4F", "#2F6FD0", "#7B4BC4", "#D6477A", "#E0A35F", "#1F1F1F")

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("musnad", Context.MODE_PRIVATE)

    fun themeIndex(ctx: Context) = prefs(ctx).getInt("theme", 0).coerceIn(0, list.size - 1)
    fun accentIndex(ctx: Context) = prefs(ctx).getInt("accent", -1)
    fun heightLevel(ctx: Context) = prefs(ctx).getInt("height", 1).coerceIn(0, 2)

    fun current(ctx: Context): Theme {
        val t = list[themeIndex(ctx)]
        val a = accentIndex(ctx)
        return if (a in accents.indices) t.copy(accent = Color.parseColor(accents[a])) else t
    }

    fun keyHeightDp(level: Int) = when (level) {
        0 -> 42
        2 -> 56
        else -> 48
    }
}
