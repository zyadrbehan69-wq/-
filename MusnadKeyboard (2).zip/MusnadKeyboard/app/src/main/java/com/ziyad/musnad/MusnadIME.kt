package com.ziyad.musnad

import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView

class MusnadIME : InputMethodService() {

    private lateinit var root: LinearLayout
    private lateinit var th: Theme
    private var keyH = 48
    private var lang = 0          // 0 = عربي، 1 = English، 2 = مسند
    private var shift = false
    private var symbols = false
    private val handler = Handler(Looper.getMainLooper())

    private val msCp = mapOf(
        "ا" to 0x10A71, "ب" to 0x10A68, "ت" to 0x10A69, "ث" to 0x10A7B, "ج" to 0x10A74,
        "ح" to 0x10A62, "خ" to 0x10A6D, "د" to 0x10A75, "ذ" to 0x10A79, "ر" to 0x10A67,
        "ز" to 0x10A78, "س" to 0x10A66, "ش" to 0x10A6F, "ص" to 0x10A6E, "ض" to 0x10A73,
        "ط" to 0x10A77, "ظ" to 0x10A7C, "ع" to 0x10A72, "غ" to 0x10A76, "ف" to 0x10A70,
        "ق" to 0x10A64, "ك" to 0x10A6B, "ل" to 0x10A61, "م" to 0x10A63, "ن" to 0x10A6C,
        "ه" to 0x10A60, "و" to 0x10A65, "ي" to 0x10A7A, "ة" to 0x10A69, "ى" to 0x10A7A,
        "ء" to 0x10A71, "ؤ" to 0x10A65, "ئ" to 0x10A7A
    )
    private val msExtra = 0x10A6A

    private fun glyph(cp: Int) = String(Character.toChars(cp))
    private fun ms(c: String) = msCp[c]?.let { glyph(it) } ?: c

    // ترتيب الحروف مطابق لصور الكيبورد
    private val arDigits = listOf("١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩", "٠")
    private val enDigits = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    private val ar1 = listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج")
    private val ar2 = listOf("ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك", "ط")
    private val ar3 = listOf("ذ", "ء", "ؤ", "ر", "ى", "ة", "و", "ز", "ظ", "د")
    private val en1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    private val en2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
    private val en3 = listOf("z", "x", "c", "v", "b", "n", "m")
    private val sym1 = listOf("@", "#", "\$", "%", "&", "-", "+", "(", ")", "/")
    private val sym2 = listOf("*", "\"", "'", ":", ";", "!", "؟", "،", "=", "_")
    private val sym3 = listOf("<", ">", "[", "]", "{", "}", "~", "|")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(3), dp(2), dp(3), dp(6))
        }
        render()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::root.isInitialized) return
        render()
        if (!restarting) {
            root.alpha = 0f
            root.translationY = dp(28).toFloat()
            root.animate().alpha(1f).translationY(0f).setDuration(200).start()
        }
    }

    // ---------- بناء المفاتيح ----------

    private fun key(
        label: String, sub: String? = null, w: Float = 1f, bg: Int = th.key,
        color: Int = th.text, size: Float = 22f, onLong: (() -> Unit)? = null,
        action: () -> Unit
    ): View {
        val tv = TextView(this)
        if (sub != null) {
            val s = SpannableString("$label\n$sub")
            s.setSpan(RelativeSizeSpan(0.45f), label.length, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            tv.text = s
        } else tv.text = label
        tv.gravity = Gravity.CENTER
        tv.textSize = size
        tv.setTextColor(color)
        tv.includeFontPadding = false
        tv.background = GradientDrawable().apply { setColor(bg); cornerRadius = dp(9).toFloat() }
        tv.elevation = dp(1).toFloat()
        tv.layoutParams = LinearLayout.LayoutParams(0, dp(keyH), w).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(60).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
            }
            false
        }
        tv.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            action()
        }
        if (onLong != null) tv.setOnLongClickListener { onLong(); true }
        return tv
    }

    private val repeatDel = object : Runnable {
        override fun run() {
            backspace()
            handler.postDelayed(this, 55)
        }
    }

    private fun backKey(w: Float): View {
        val v = key("⌫", w = w, bg = th.key2, size = 20f) { }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.animate().scaleX(0.93f).scaleY(0.93f).setDuration(60).start()
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    backspace()
                    handler.postDelayed(repeatDel, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeatDel)
                    view.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                }
            }
            true
        }
        return v
    }

    private fun spacer(w: Float) = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, w) }

    private fun row(items: List<View>) {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
        }
        items.forEach { r.addView(it) }
        root.addView(r)
    }

    private fun charKey(c: String): View =
        if (lang == 2) {
            val g = ms(c)
            key(g, sub = c, size = 22f) { type(g) }
        } else key(c, size = 24f) { type(c) }

    private fun plainKey(c: String): View = key(c, size = 22f) { type(c) }

    // ---------- الرسم ----------

    private fun render() {
        th = Themes.current(this)
        keyH = Themes.keyHeightDp(Themes.heightLevel(this))
        root.removeAllViews()
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(th.top, th.bottom))

        root.addView(toolbar())

        val digits = if (lang == 1) enDigits else arDigits
        row(digits.map { plainKey(it) })

        if (symbols) {
            row(sym1.map { plainKey(it) })
            row(sym2.map { plainKey(it) })
            row(sym3.map { plainKey(it) } + backKey(1.5f))
        } else when (lang) {
            1 -> {
                fun cased(c: String) = if (shift) c.uppercase() else c
                row(en1.map { c -> cased(c).let { v -> key(v, size = 24f) { type(v) } } })
                row(listOf(spacer(0.5f)) + en2.map { c -> cased(c).let { v -> key(v, size = 24f) { type(v) } } } + spacer(0.5f))
                val shiftKey = key(if (shift) "⇧" else "⇪", w = 1.5f,
                    bg = if (shift) th.accent else th.key2,
                    color = if (shift) Color.WHITE else th.text, size = 20f) { shift = !shift; render() }
                row(listOf(shiftKey) + en3.map { c -> cased(c).let { v -> key(v, size = 24f) { type(v) } } } + backKey(1.5f))
            }
            else -> {
                row(ar1.map { charKey(it) })
                row(ar2.map { charKey(it) })
                row(ar3.map { charKey(it) } + backKey(1.3f))
            }
        }
        row(bottomRow())
    }

    private fun bottomRow(): List<View> {
        val isEn = lang == 1
        val symLabel = if (symbols) (if (isEn) "ABC" else "أبج") else (if (isEn) "?123" else "؟٣٢١")
        val symKey = key(symLabel, w = 1.7f, bg = th.key2, size = 15f) { symbols = !symbols; render() }

        val commaKey = if (lang == 2 && !symbols) {
            key(glyph(msExtra), sub = "·", size = 22f) { type(glyph(msExtra)) }
        } else {
            val cm = if (isEn) "," else "،"
            key(cm, size = 22f) { type(cm) }
        }

        val globe = key("🌐", size = 20f) {
            lang = (lang + 1) % 3
            shift = false
            symbols = false
            render()
        }

        val spaceLabel = when (lang) {
            1 -> "English"
            2 -> "مسند " + glyph(0x10A63) + glyph(0x10A66) + glyph(0x10A6C) + glyph(0x10A75)
            else -> "العربية"
        }
        val space = key(spaceLabel, w = 4.2f, size = 14f, onLong = {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }) { type(" ") }

        val dot = key(".", size = 22f) { type(".") }
        val act = key(actionLabel(), w = 1.7f, bg = th.accent, color = Color.WHITE, size = 20f) { enter() }

        return listOf(symKey, commaKey, globe, space, dot, act)
    }

    private fun toolbar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40))
        }
        fun tool(txt: String, action: () -> Unit) = TextView(this).apply {
            text = txt
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(th.text)
            layoutParams = LinearLayout.LayoutParams(dp(48), LinearLayout.LayoutParams.MATCH_PARENT)
            setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); action() }
        }
        bar.addView(tool("⚙") {
            val i = Intent(this, SettingsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        })
        bar.addView(tool("📋") { pasteClipboard() })
        bar.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
        bar.addView(TextView(this).apply {
            text = when (lang) { 1 -> "English"; 2 -> "مسند"; else -> "العربية" }
            textSize = 13f
            setTextColor(th.accent)
            setPadding(0, 0, dp(12), 0)
        })
        return bar
    }

    // ---------- الإدخال ----------

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
        if (shift && lang == 1 && !symbols) { shift = false; render() }
    }

    private fun pasteClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!t.isNullOrEmpty()) currentInputConnection?.commitText(t, 1)
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        if (!ic.getSelectedText(0).isNullOrEmpty()) ic.commitText("", 1)
        else ic.deleteSurroundingTextInCodePoints(1, 0)
    }

    private fun imeAction(): Int {
        val o = currentInputEditorInfo?.imeOptions ?: 0
        return if ((o and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) EditorInfo.IME_ACTION_NONE
        else o and EditorInfo.IME_MASK_ACTION
    }

    private fun actionLabel(): String = when (imeAction()) {
        EditorInfo.IME_ACTION_SEARCH -> "🔍"
        EditorInfo.IME_ACTION_SEND -> "➤"
        EditorInfo.IME_ACTION_GO -> "➜"
        EditorInfo.IME_ACTION_DONE -> "✓"
        EditorInfo.IME_ACTION_NEXT -> "⇥"
        else -> "↵"
    }

    private fun enter() {
        val a = imeAction()
        if (a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED)
            currentInputConnection?.performEditorAction(a)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }
}
