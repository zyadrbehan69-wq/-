package com.ziyad.musnad

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SettingsActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    private fun title(t: String) = TextView(this).apply {
        text = t
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(20), 0, dp(8))
    }

    private fun swatch(top: Int, bottom: Int, label: String, selected: Boolean, onClick: () -> Unit): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
            setOnClickListener { onClick() }
        }
        val dot = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(if (selected) 4 else 1), if (selected) Color.parseColor("#9A5B1E") else Color.GRAY)
            }
        }
        box.addView(dot)
        box.addView(TextView(this).apply { text = label; textSize = 12f; gravity = Gravity.CENTER })
        return box
    }

    private fun build() {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(36), dp(20), dp(28))
        }
        sv.addView(col)

        col.addView(TextView(this).apply { text = "الإعدادات"; textSize = 26f; typeface = Typeface.DEFAULT_BOLD })

        // --- المظهر ---
        col.addView(title("مظهر الكيبورد"))
        val themeIdx = Themes.themeIndex(this)
        Themes.list.chunked(3).forEachIndexed { r, chunk ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            chunk.forEachIndexed { i, t ->
                val idx = r * 3 + i
                line.addView(swatch(t.top, t.bottom, t.name, idx == themeIdx) {
                    Themes.prefs(this).edit().putInt("theme", idx).apply()
                    build()
                })
            }
            col.addView(line)
        }

        // --- لون المفتاح الرئيسي ---
        col.addView(title("لون زر الإدخال"))
        val accIdx = Themes.accentIndex(this)
        val accLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        accLine.addView(swatch(Color.WHITE, Color.LTGRAY, "افتراضي", accIdx == -1) {
            Themes.prefs(this).edit().putInt("accent", -1).apply()
            build()
        })
        Themes.accents.forEachIndexed { i, hex ->
            val c = Color.parseColor(hex)
            accLine.addView(swatch(c, c, "", accIdx == i) {
                Themes.prefs(this).edit().putInt("accent", i).apply()
                build()
            })
        }
        col.addView(android.widget.HorizontalScrollView(this).apply { addView(accLine) })

        // --- حجم المفاتيح ---
        col.addView(title("حجم المفاتيح"))
        val hLine = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        listOf("صغير", "متوسط", "كبير").forEachIndexed { i, n ->
            hLine.addView(Button(this).apply {
                text = n
                alpha = if (Themes.heightLevel(this@SettingsActivity) == i) 1f else 0.5f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    Themes.prefs(this@SettingsActivity).edit().putInt("height", i).apply()
                    build()
                }
            })
        }
        col.addView(hLine)

        // --- تجربة ---
        col.addView(title("جرّب الكيبورد"))
        col.addView(EditText(this).apply { hint = "اكتب هنا لرؤية التغييرات"; textSize = 20f })

        // --- حول التطبيق ---
        col.addView(Button(this).apply {
            text = "حول التطبيق"
            setOnClickListener {
                AlertDialog.Builder(this@SettingsActivity)
                    .setTitle("حول التطبيق")
                    .setMessage("كيبورد مسند\nعربي · English · مسند\nالإصدار 1.0\n\nالمطوّر: Zyad")
                    .setPositiveButton("حسنًا", null)
                    .show()
            }
        })

        setContentView(sv)
    }
}
