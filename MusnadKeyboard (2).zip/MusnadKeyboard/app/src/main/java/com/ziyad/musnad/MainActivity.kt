package com.ziyad.musnad

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val frame = FrameLayout(this)
        frame.addView(buildMain())

        // ----- شاشة الدخول المتحركة -----
        val brown = Color.parseColor("#9A5B1E")
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(brown)
            isClickable = true
        }
        val glyphRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
        }
        // م س ن د بخط المسند
        val cps = intArrayOf(0x10A63, 0x10A66, 0x10A6C, 0x10A75)
        val glyphViews = cps.map { cp ->
            TextView(this).apply {
                text = String(Character.toChars(cp))
                textSize = 56f
                setTextColor(Color.WHITE)
                setPadding(dp(8), 0, dp(8), 0)
                alpha = 0f
                scaleX = 0.3f
                scaleY = 0.3f
            }
        }
        glyphViews.forEach { glyphRow.addView(it) }
        val title = TextView(this).apply {
            text = "كيبورد مسند"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            alpha = 0f
            translationY = dp(24).toFloat()
        }
        val sub = TextView(this).apply {
            text = "عربي · English · مسند"
            textSize = 15f
            setTextColor(Color.parseColor("#F3DFC8"))
            gravity = Gravity.CENTER
            alpha = 0f
        }
        splash.addView(glyphRow)
        splash.addView(title)
        splash.addView(sub)
        frame.addView(splash, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(frame)

        glyphViews.forEachIndexed { i, v ->
            v.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay(i * 180L).setDuration(380)
                .setInterpolator(OvershootInterpolator()).start()
        }
        title.animate().alpha(1f).translationY(0f).setStartDelay(900).setDuration(400).start()
        sub.animate().alpha(1f).setStartDelay(1150).setDuration(400).start()
        splash.animate().alpha(0f).setStartDelay(2100).setDuration(450)
            .withEndAction { frame.removeView(splash) }.start()
    }

    private fun buildMain(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        col.addView(TextView(this).apply {
            text = "كيبورد مسند"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "عربي · English · مسند\n\n١) اضغط «تفعيل الكيبورد» وشغّل «كيبورد مسند».\n٢) اضغط «اختيار الكيبورد» واختره.\n٣) غيّر اللغة من زر 🌐 الموجود في الكيبورد (عربي ← English ← مسند).\n٤) من ⚙ أو من زر الإعدادات تقدر تغيّر الألوان والمظهر."
            textSize = 16f
            setPadding(0, dp(12), 0, dp(16))
        })
        col.addView(Button(this).apply {
            text = "تفعيل الكيبورد"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "اختيار الكيبورد"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        col.addView(Button(this).apply {
            text = "الإعدادات"
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        col.addView(EditText(this).apply { hint = "جرّب الكتابة هنا"; textSize = 20f })
        return col
    }
}
