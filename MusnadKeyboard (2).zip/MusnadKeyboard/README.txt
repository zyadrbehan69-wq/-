كيبورد مسند - مشروع أندرويد (Kotlin)

1) افتح المجلد في Android Studio (إصدار Koala أو أحدث) وانتظر مزامنة Gradle.
2) من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s)
3) الملف الناتج: app/build/outputs/apk/debug/app-debug.apk
4) انقله للجوال وثبّته (فعّل "التثبيت من مصادر غير معروفة").
5) افتح التطبيق: فعّل الكيبورد ثم اختره.

الكيبورد يشتغل بدون إنترنت بالكامل. خط المسند يأتي من خطوط أندرويد (Noto Sans Old South Arabian)،
وإذا ما ظهرت الحروف على جهاز قديم أضف ملف خط .ttf في app/src/main/res/font واستخدمه في MusnadIME.
